/*
 * ============================================
 * // Autor: Feisheng Original
 * 交流群: 123456789
 * v3.1α
 * 版权所有，侵权必究
 * ============================================
 */

/* ================= 决策积分引擎 · 数值表（整合模块） ================= */
export const VAL_CARD = {
	sha: { use: 2, resp: 1, name: "杀" }, shan: { use: 1, resp: 2, name: "闪" },
	tao: { use: 2, resp: 3, name: "桃" }, jiu: { use: 1, name: "酒" },
	juedou: { use: 2, name: "决斗" }, nanman: { use: 3, name: "南蛮入侵" },
	wanjian: { use: 3, name: "万箭齐发" }, huogong: { use: 2, name: "火攻" },
	guohe: { use: 2, name: "过河拆桥" }, shunshou: { use: 3, name: "顺手牵羊" },
	zhujin: { use: 3, name: "诛杀" }, wuzhong: { use: 2, name: "无中生有" },
	taoyuan: { use: 3, name: "桃园结义" }, wugu: { use: 2, name: "五谷丰登" },
	jiedao: { use: 2, name: "借刀杀人" }, tiesuo: { use: 2, name: "铁索连环" },
	lebu: { use: 2, name: "乐不思蜀" }, bingliang: { use: 2, name: "兵粮寸断" },
	shandian: { use: -2, name: "闪电" }, wuxie: { use: 1, resp: 2, name: "无懈可击" },
	zhuge: { use: 3, name: "诸葛连弩" }, fangtian: { use: 2, name: "方天画戟" },
	qinggang: { use: 2, name: "青釭剑" }, guding: { use: 2, name: "古锭刀" },
	guanshi: { use: 2, name: "贯石斧" }, hanbing: { use: 2, name: "寒冰剑" },
	qilin: { use: 2, name: "麒麟弓" }, zhangba: { use: 2, name: "丈八蛇矛" },
	cixiong: { use: 2, name: "雌雄双股剑" }, zhuque: { use: 2, name: "朱雀羽扇" },
	yiyang: { use: 2, name: "倚天剑" }, qinglong: { use: 2, name: "青龙偃月刀" },
	renwang: { use: 2, name: "仁王盾" }, bagua: { use: 2, name: "八卦阵" },
	tengjia: { use: 2, name: "藤甲" }, baiyin: { use: 2, name: "白银狮子" },
	dilu: { use: 1, name: "的卢" }, jueying: { use: 1, name: "绝影" },
	chitu: { use: 1, name: "赤兔" }, dawan: { use: 1, name: "大宛" },
	zixin: { use: 1, name: "紫骍" }, hualiu: { use: 1, name: "骅骝" },
	zhuahuang: { use: 1, name: "爪黄飞电" }, xuanhua: { use: 2, name: "玄化" },
	muniu: { use: 1, name: "木牛流马" },
	chixueqingfeng: { use: 2, name: "赤血青锋" },
	liuyang: { use: 2, name: "流杨" },
	guanyinping: { use: 2, name: "观音平" },

	/* ★ 补充：标准/军争/SP 全卡牌 */
	huoshai: { use: 2, name: "火烧连营" },
	guochu: { use: 2, name: "国除" },
	jueqiang: { use: 2, name: "驱虎吞狼" },
	tianyi: { use: 2, name: "天义" },
	yijue: { use: 2, name: "离间" },
	zhiheng: { use: 1, name: "制衡" },
	jijiang: { use: 1, name: "激将" },
	hujia: { use: 1, name: "护驾" },
	jijie: { use: 1, name: "结姻" },
	zongheng: { use: 1, name: "纵横" },

	/* 补充装备 */
	taia: { use: 2, name: "太阿剑" },
	zizhu: { use: 2, name: "紫鬃马" },
	luoshen: { use: 2, name: "洛神剑" },
	bagua2: { use: 2, name: "八卦阵·改" },
	tengjia2: { use: 2, name: "藤甲·改" },
	renwang2: { use: 2, name: "仁王盾·改" },

	/* ★ 衍生卡牌 */
	xizhao: { use: 2, name: "檄诏" },
	diaobing: { use: 2, name: "调兵" },
	liezhen: { use: 1, name: "列阵" },
	mizhao: { use: 2, name: "密诏" },
	duanming: { use: 3, name: "夺命" },
	huosha: { use: 2, name: "火杀" },
	leisha: { use: 2, name: "雷杀" },
_shalei: { use: 2, name: "杀·雷" },
	huopo: { use: 2, name: "火魄" },
	dunpai: { use: 1, name: "盾牌" },
	bingfu: { use: 1, name: "兵符" },
	madao: { use: 1, name: "马刀" },
	gongjian: { use: 1, name: "弓箭" },
	qiang: { use: 1, name: "长枪" },

	/* ★ 更多基础元素：武将技能衍生牌 */
	fangzhu: { use: 2, name: "放逐" },
	bige: { use: 1, name: "悲歌" },
	fankui: { use: 1, name: "反馈" },
	jijing: { use: 1, name: "集智" },
	zhiheng2: { use: 1, name: "制衡·改" },
	tuxi: { use: 2, name: "突袭" },
	zhuangshu: { use: 1, name: "装束" },
	zhendong: { use: 2, name: "震东" },
	mingce: { use: 1, name: "明策" },
	huyuan: { use: 1, name: "护援" },
	jijiu: { use: 1, name: "救急" },
	duanliang: { use: 2, name: "断粮" },
	qicai: { use: 1, name: "奇策" },
	tuxi2: { use: 2, name: "突袭·改" },

	/* ★ 更多基础元素：游戏阶段/状态 */
	panduan: { use: 0, name: "判定阶段" },
	mopai: { use: 0, name: "摸牌阶段" },
	chupai: { use: 0, name: "出牌阶段" },
	qipai: { use: 0, name: "弃牌阶段" },
	jieshu: { use: 0, name: "结束阶段" },
};

export const CARD_RULE = {
	sha: { tgt: "敌方低血/无闪优先", cond: "有击杀或压制需求", w: 2 },
	shan: { tgt: "自己", cond: "响应杀（防御+2）", w: 2 },
	tao: { tgt: "自己/濒死队友", cond: "濒死优先救", w: 3 },
	jiu: { tgt: "自己", cond: "濒死保命或酒杀强中", w: 1 },
	juedou: { tgt: "敌方手牌杀少者", cond: "自己杀多/敌杀少时", w: 2 },
	nanman: { tgt: "全体敌方", cond: "敌方缺杀时收益最高", w: 3 },
	wanjian: { tgt: "全体敌方", cond: "敌方缺闪时收益最高", w: 3 },
	huogong: { tgt: "敌方高血/有明牌", cond: "能弃同花色牌时", w: 2 },
	zhujin: { tgt: "敌方低血", cond: "必中伤害", w: 3 },
	guohe: { tgt: "敌方关键装备/乐兵/手牌多者", cond: "优先拆关键装备和判定牌", w: 2 },
	shunshou: { tgt: "敌方手牌/装备价值高者", cond: "距离内优先拿装备", w: 3 },
	jiedao: { tgt: "有杀之敌", cond: "借敌杀敌", w: 2 },
	tiesuo: { tgt: "敌方横置（配合属性杀/火攻）", cond: "能连人多时", w: 2 },
	lebu: { tgt: "即将行动的威胁敌", cond: "优先乐高威胁/蓄爆敌", w: 2 },
	bingliang: { tgt: "敌方", cond: "压制敌方过牌", w: 2 },
	shandian: { tgt: "自己（血多）/敌方", cond: "风险高（-2），慎用", w: -2 },
	wuxie: { tgt: "响应", cond: "解关键锦囊/保判定", w: 2 },
	wuzhong: { tgt: "自己", cond: "直接使用（+2）", w: 2 },
	taoyuan: { tgt: "己方全体", cond: "队友低血时收益高", w: 3 },
	wugu: { tgt: "全体", cond: "先选高价值牌", w: 2 },
	zhuge: { tgt: "自己", cond: "手牌多杀时装备（爆发）", w: 3 },
	fangtian: { tgt: "自己", cond: "多目标输出", w: 2 },
	qinggang: { tgt: "自己", cond: "无视防具", w: 2 },
	guding: { tgt: "自己", cond: "对手无手牌时伤害+1", w: 2 },
	guanshi: { tgt: "自己", cond: "攻击范围", w: 2 },
	hanbing: { tgt: "自己", cond: "伤害可弃牌（控手牌）", w: 2 },
	qilin: { tgt: "自己", cond: "杀弃装备（拆装备）", w: 2 },
	zhangba: { tgt: "自己", cond: "两张当杀", w: 2 },
	cixiong: { tgt: "自己", cond: "异性额外收益", w: 2 },
	zhuque: { tgt: "自己", cond: "火杀强化", w: 2 },
	yiyang: { tgt: "自己", cond: "伤害回血", w: 2 },
	qinglong: { tgt: "自己", cond: "杀可追刀", w: 2 },
	renwang: { tgt: "自己", cond: "防黑杀", w: 2 },
	bagua: { tgt: "自己", cond: "判定闪（防御）", w: 2 },
	tengjia: { tgt: "自己", cond: "防杀但惧火（慎）", w: 2 },
	baiyin: { tgt: "自己", cond: "限伤+回血", w: 2 },
	dilu: { tgt: "自己", cond: "防顺手/距离", w: 1 },
	jueying: { tgt: "自己", cond: "防杀距离", w: 1 },
	chitu: { tgt: "自己", cond: "+1距离进攻", w: 1 },
	dawan: { tgt: "自己", cond: "+1距离进攻", w: 1 },
	zixin: { tgt: "自己", cond: "+1距离进攻", w: 1 },
	hualiu: { tgt: "自己", cond: "+1距离进攻", w: 1 },
	zhuahuang: { tgt: "自己", cond: "+1距离进攻", w: 1 },
	muniu: { tgt: "自己/队友", cond: "传牌给队友（辅助流通）", w: 2 },
	chixueqingfeng: { tgt: "自己", cond: "特殊武器（高收益）", w: 2 },
};

export const VAL_EFFECT = {
	damage: 2, loseHp: 2, recover: 2, gainMaxHp: 2, loseMaxHp: -2,
	draw: 1, gain: 1, discard: -1.5, lose: -1,
	turnOver: -2, turnBack: 2, link: -2, unlink: 2,
	handUp: 1, handDown: -1, playUp: 1, playDown: -1,
	dmgUp: 1, dmgDown: -1, death: 4, die: -4,
	restoreEquip: 2, abolishEquip: -2, addMark: 0, removeMark: 0,
	equip: 1, judge: 1, dying: 3, save: 3,
};

export const VAL_TIMING = {
	/* 回合与阶段 */
	gameStart: 0, roundStart: 0.5, phaseBegin: 0, phaseBefore: 0, phaseAfter: 0,
	phaseBeginStart: 0.5, phaseEnd: 0, phaseZhunbeiBegin: 0.5, phaseJudgeBegin: 0,
	phaseDrawBegin: 1, phaseUseBegin: 0.5, phaseUseEnd: 0, phaseDiscardBegin: -0.5, phaseDiscardEnd: -1,
	checkBegin: 0, checkEnd: 0,
	/* 伤害与濒死 */
	damageBefore: 0, damageAfter: 2, damageEnd: 0, damageCaused: 2,
	dying: 3, dieBefore: 1, dieAfter: 3, loseHpEnd: 2, loseHpAfter: 2,
	/* 牌与效果 */
	drawBegin: 1, discardBegin: -0.5, discardAfter: -1, loseAfter: -1, loseAsyncAfter: -1,
	gainAfter: 1, gainMaxHpBegin: 1, loseMaxHpBegin: -1, equipAfter: 1,
	turnOverAfter: -2, useCardBefore: 0.5, useCardAfter: 1, recoverBefore: 0,
	addJudgeAfter: 0, addToExpansionAfter: 0, gainPlayerCardBegin: 1,
	/* 选择与响应（异步） */
	chooseToUse: 1, chooseToUseBegin: 0.5, chooseToRespond: 2, chooseToRespondBegin: 0.5,
	chooseToDiscardBegin: -0.5, chooseTargetBegin: 0, chooseCardBegin: 0, chooseControlBegin: 0,
	chooseButtonBegin: 0, chooseButtonTargetBegin: 0, chooseBoolBegin: 0, chooseNumbersBegin: 0,
	choosePlayerCardBegin: 0, chooseToCompareBegin: 0, chooseToGiveBegin: 0, chooseToGuanxingBegin: 0,
	chooseToMoveBegin: 0, chooseToPlayBeatmapBegin: 0, respondBefore: 1, switchToAuto: 0,
	/* 其他 */
	restEnd: 0, ContentAfter: 0, ContentBefore: 0, uncheckBegin: 0, uncheckEnd: 0,
	roundStart2: 0.5, iWannaTopCards: 1, loseToDiscardpileAfter: -1, discardPlayerCardBegin: -0.5,
};

export const STRATEGY = {
	gameStart: { act: "蓄爆", txt: "开局摸清身份/形势，蓄爆关键牌（顺/拆/杀/无懈），不轻易交牌" },
	roundStart: { act: "规划", txt: "每回合开始先判定局势：进攻/防守/发育三选一，确定本回合主目标" },
	phaseZhunbeiBegin: { act: "准备", txt: "准备阶段：有判定先处理判定，技能可发则评估收益" },
	phaseDrawBegin: { act: "过牌", txt: "摸牌阶段：保证过牌质量，摸牌收益为正（+1/张）" },
	phaseUseBegin: { act: "控→输出", txt: "出牌阶段：先装备/拆顺控制，再输出；技能权重高于出牌" },
	useCardBefore: { act: "评估", txt: "出牌前评估目标与收益：攻击牌优先打威胁最大/明身份敌对目标" },
	useCardAfter: { act: "追加", txt: "出牌后若能追加输出（连弩/技能联动）优先追加，回合内多使用牌积分叠加" },
	damageBefore: { act: "预判", txt: "伤害前预判：目标有桃/濒死则先拆桃或改打，避免无效输出" },
	damageAfter: { act: "补刀", txt: "伤害后可补刀（手牌杀/决斗/技能）优先收割，击杀收益最高（+4）" },
	dying: { act: "保命", txt: "濒死优先保命：桃/酒/无懈；队友濒死也救（救援+3）" },
	dieAfter: { act: "围剿", txt: "敌方阵亡后调整目标，优先围剿剩余最大威胁；胜利阵营结算得分" },
	phaseDiscardEnd: { act: "留防", txt: "弃牌阶段超上限弃牌惩罚加重（-1.5/张），优先保留价值牌（闪/桃/无懈/装备）" },
	turnOverAfter: { act: "防翻", txt: "翻面收益大减（-2），避免被连续翻面；己方翻面后以防守为主" },
	equipAfter: { act: "装备", txt: "装备价值高（武器+2~3/防具+2），优先装备提升攻防" },
	chooseToUse: { act: "收益决策", txt: "选择使用：按净收益决策（技能/卡牌收益>0才用），得分即权重" },
	chooseToRespond: { act: "防御", txt: "响应（闪/无懈）：防御收益高（+2），优先响应关键伤害/锦囊" },
	chooseToDiscardBegin: { act: "控弃", txt: "被迫弃牌时优先弃低价值牌（基本杀>锦囊>装备>闪/桃/无懈）" },
	switchToAuto: { act: "托管", txt: "AI 托管接管：按本策略表+价值表自动决策，积分驱动行为" },
	addJudgeAfter: { act: "判定", txt: "判定类（乐/兵/闪电）：判定成功=限制敌方收益，失败=风险自担" },
	gainMaxHpBegin: { act: "发育", txt: "体力上限提升收益高（+2），优先保留此类技能时机" },
	loseMaxHpBegin: { act: "受损", txt: "体力上限降低损失大（-2），避免触发此类负面效果" },
};

export const SKILL_RULE = {
	jianxiong: { cond: "被伤害后拿伤害牌（收益高）", w: 2 },
	fankui: { cond: "受伤害拆敌牌（优先拆装备/关键牌）", w: 2 },
	yiji: { cond: "受伤害摸牌分牌（给己方好牌）", w: 2 },
	ganglie: { cond: "受伤害刚烈（敌血少慎用）", w: 1 },
	qingnang: { cond: "己方低血回血（满血不发动）", w: 2 },
	yingzi: { cond: "摸牌阶段多摸（收益+1）", w: 2 },
	haoshi: { cond: "摸牌阶段多摸（手牌少时）", w: 2 },
	luoyi: { cond: "手牌少需输出时发动", w: 1 },
	wuyan: { cond: "弃牌换杀（输出流）", w: 1 },
	wusheng: { cond: "红牌当杀（输出）", w: 2 },
	paoxiao: { cond: "手牌多杀（连杀爆发）", w: 2 },
	liegong: { cond: "杀无闪目标（强中）", w: 2 },
	wuqian: { cond: "决斗强化（手牌多杀）", w: 1 },
	qixi: { cond: "黑牌当拆（控手牌/装备）", w: 2 },
	guose: { cond: "红牌当乐（控高威胁敌）", w: 2 },
	jieyin: { cond: "弃装备回血（低血时）", w: 2 },
	bazhen: { cond: "无闪判定（防御）", w: 2 },
	fangzhu: { cond: "受伤翻人（控制敌/保己）", w: 2, branch: "翻面目标：威胁最高敌方" },
	huatuo: { cond: "红牌当桃（保命/救队友）", w: 2 },
	renxin: { cond: "濒死保命（桃当酒）", w: 2 },
	jizhi: { cond: "使用锦囊摸牌（过牌联动）", w: 2 },
	leiji: { cond: "闪后雷击（反击高威胁敌）", w: 2, tgt: "敌方高威胁" },
	guicai: { cond: "改判（护己方判定/害敌方判定）", w: 2 },
	kongcheng: { cond: "无手牌免杀/决斗（防御站场）", w: 2 },
	luoshen: { cond: "判定黑牌摸牌（收益+1/张）", w: 2 },
	fanjian: { cond: "弃牌猜花色（控敌手牌）", w: 2, tgt: "敌方手牌多者" },
	tieji: { cond: "杀判定红强中（无视闪）", w: 2, tgt: "敌方无闪/低血" },
	hujia: { cond: "主公技：杀闪通用（防御）", w: 2 },
	jiushi: { cond: "翻面当酒（残血爆发）", w: 1, branch: "翻面代价大：非濒死慎用" },
	luanji: { cond: "两张当万箭（清场）", w: 2, tgt: "敌方缺闪时" },
	shensu: { cond: "跳阶段出杀（抢节奏）", w: 2, tgt: "敌方无闪/低血" },
	qiaobian: { cond: "弃牌跳阶段（控场）", w: 2 },
	jijiang: { cond: "主公技：借队友杀（输出）", w: 2 },
	xingshang: { cond: "收尸摸牌（阵亡后爆发）", w: 1 },
	wangxi: { cond: "受伤摸牌（过牌）", w: 2 },
	xunxun: { cond: "看四选二（优化手牌）", w: 2 },
	ganlu: { cond: "换装备（夺敌装备）", w: 2, tgt: "敌方装备价值高者" },
	zhaolie: { cond: "扣血换牌（残血爆发）", w: 1 },
	benxi: { cond: "杀强中（无视闪）", w: 2, tgt: "敌方无闪/低血" },
	jiangchi: { cond: "杀强中（无视闪）", w: 2, tgt: "敌方无闪/低血" },
	badao: { cond: "主公技：杀强中（无视闪）", w: 2, tgt: "敌方无闪/低血" },
	huangtian: { cond: "主公技：借判定（控场）", w: 2 },
	kuanggu: { cond: "摸牌或回血（灵活选择）", w: 2, branch: "低血选回血，否则摸牌" },
	jianxiong2: { cond: "被伤害后拿伤害牌（收益高）", w: 2 },
	fankui2: { cond: "受伤害拆敌牌", w: 2 },
	yiji2: { cond: "受伤害摸牌分牌", w: 2 },
	luoshen2: { cond: "判定黑牌摸牌", w: 2 },
	jianyan: { cond: "主公技：弃牌辅助", w: 1 },
	zhiheng: { cond: "弃牌换牌（灵活过牌）", w: 2, branch: "弃最少牌换牌（优先弃杀/废牌）" },
	guanxing: { cond: "控顶（判定/摸牌优化）", w: 2 },
	duoshi: { cond: "手牌上限+（存牌）", w: 1 },
};

/* 无名AI卡牌价值体系 */
export const AI_CARD_VALUE = {
	/* 基础牌（低血时保命优先，正常时防御优先；属性杀+1） */
	basic_low: { tao: 10, jiu: 9, shan: 8, sha: 6 },
	basic_normal: { shan: 10, tao: 9, sha: 7, jiu: 6 },
	/* 武器（铁索→朱雀10/古锭+1；敌无手牌→古锭10） */
	weapon: { zhuge: 9, qinggang: 8, guanshi: 7, qilin: 6, qinglong: 5, zhangba: 4, fangtian: 3, zhuque: 2, guding: 1 },
	/* 防具（敌有火雷杀→藤甲降为5） */
	armor: { bagua: 9, renwang: 8, tengjia: 7, baiyin: 6 },
	armor_fire: { bagua: 9, renwang: 8, baiyin: 7, tengjia: 5 },
	/* 锦囊（有改判→闪电10） */
	trick: { 
		wuxie: 10, 
		wuzhong: 11,        /* ★ 无中生有：纯收益神牌，优先级最高 */
		lebu: 9,            /* 乐不思蜀：基础分，使用时加敌我判断 */
		bingliang: 9,       /* 兵粮寸断：基础分，使用时加敌我判断 */
		nanman: 8,         /* ★ 南蛮入侵：群体伤害，敌人缺杀时收益爆炸 */
		wanjian: 8,        /* ★ 万箭齐发：群体伤害，敌人缺闪时收益爆炸 */
		guohe: 7,         /* ★ 过河拆桥：拆关键装备/判定牌收益高 */
		shunshou: 6.5,    /* ★ 顺手牵羊：拿敌人装备是好事 */
		wugu: 5, 
		tiesuo: 5,        /* ★ 铁索连环：连敌人配合属性杀 */
		huogong: 4, 
		taoyuan: 5,       /* ★ 桃园结义：队友残血时收益极高 */
		jiedao: 2, 
		shandian: 1,      /* 闪电：基础分，使用时加敌我判断 */
	},
	trick_rejudge: { shandian: 10, wuxie: 9, lebu: 8, bingliang: 8, wuzhong: 9, nanman: 7, wanjian: 7, guohe: 6, shunshou: 5.5, wugu: 4, tiesuo: 4, huogong: 3, taoyuan: 3, jiedao: 1 },
};

/* ★ 敌我阵营调整系数（延时锦囊/控制牌使用时根据目标阵营加减分） */
export const CARD_ALIGN_MOD = {
	/* 延时锦囊：贴敌人加分，贴队友减分 */
	lebu: { enemy: 2, ally: -2 },
	bingliang: { enemy: 1.5, ally: -1.5 },
	shandian: { enemy: 1, ally: -2 },
	/* 控制牌：拆敌人加分，拆队友减分 */
	guohe: { enemy: 1, ally: -1 },
	shunshou: { enemy: 0.5, ally: -1 },
	/* 铁索：连敌人加分，连队友减分 */
	tiesuo: { enemy: 1, ally: -1 },
};
