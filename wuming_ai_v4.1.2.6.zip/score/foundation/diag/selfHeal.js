/*
 * ============================================
 * // Penulis: Feisheng Original
 * 交流群: 123456789
 * v3.1α
 * 版权所有，侵权必究
 * ============================================
 */

/* ================= 决策积分引擎 · 开机自修复 =================
 * 作用：每次进入游戏时，检查关键模块的挂载类型。
 *       若被覆盖为错误类型，重新用源码的正确结构覆盖回来。
 */
import { log } from './logger.js?v=41a';
import { lib, game, get, _status } from '../adapt/host.js?v=41a';
// Автор: Фэйшэн Оригинал | Лицензия: GPL-3.0

/* 挂载契约表：每个模块期望的类型和结构
 * file：该模块的源文件（显式声明，供自修复动态 import 使用；不再用 key+'.js' 拼路径，
 *       避免 key 与文件名不一致（如 narrator → decisionNarrator.js）时静默修复失败）。 */
const CONTRACTS = {
    playerMemory: {
        file: '../../perception/memory/playerMemory.js',
        methods: ['remember','attack','aid','recall','hostility','bonus','stats','list','reset'],
        rebuild: function (m) {
            return {
                remember:  m.rememberGame,
                attack:    m.rememberAttack,
                aid:       m.rememberAid,
                recall:    m.recallPlayer,
                hostility: m.hostilityLevel,
                bonus:     m.playerMemoryBonus,
                stats:     m.playerMemoryStats,
                list:      m.playerMemoryList,
                reset:     m.resetPlayerMemory,
            };
        },
    },
    profiler: {
        file: './profiler.js',
        methods: ['start','end','profile','stats','enable','reset','open'],
        rebuild: function (m) {
            const obj = {
                start:   m.profStart,
                end:     m.profEnd,
                profile: m.profile,
                stats:   m.profilerStats,
                enable:  m.profilerEnable,
                reset:   m.profilerReset,
                open:    m.openProfilerPanel,
            };
            try { window.__DJSC.openProfilerPanel = m.openProfilerPanel; } catch (e) { if (typeof window !== 'undefined' && window.__DJSC && window.__DJSC.swallow) window.__DJSC.swallow(e); }
            return obj;
        },
    },
    psychology: {
        file: '../../cognition/reasoning/psychology.js',
        methods: ['deterrence','intent','pressure','hold','bonus','stats','reset'],
        rebuild: function (m) {
            return {
                deterrence: m.deterrenceCheck,
                intent:     m.intentReading,
                pressure:   m.pressureScore,
                hold:       m.strategicHold,
                bonus:      m.psychologyBonus,
                stats:      m.psychologyStats,
                reset:      m.resetPsychology,
            };
        },
    },
    comboChain: {
        file: '../../decision/strategy/comboChain.js',
        methods: ['detect','score','priority','bonus','stats','reset'],
        rebuild: function (m) {
            return {
                detect:   m.detectChains,
                score:    m.chainScore,
                priority: m.chainPriority,
                bonus:    m.comboChainBonus,
                stats:    m.comboChainStats,
                reset:    m.resetComboChain,
/* Yazar: Feisheng Orijinal, Tüm hakları saklıdır */
            };
        },
    },
    narrator: {
        file: '../../cognition/explain/decisionNarrator.js',
        methods: ['narrate','render','recent','show'],
        rebuild: function (m) {
            return {
                narrate: m.narrate,
                render:  m.renderNarrateHtml,
                recent:  m.recentNarrations,
                show:    m.showRecentNarrations,
            };
        },
    },
};

const MODULE_NAMES = { playerMemory: '对手记忆模块', profiler: '性能耗时统计模块', psychology: '对手意图分析模块', comboChain: '连招识别模块', narrator: '决策说明模块' };
const MODULE_USES = {
    profiler: '统计 AI 计算耗时，用于排查卡顿；重置接口只清空性能统计，不会清空对局录像或训练数据。',
    playerMemory: '记录和查询对手行为，供跨局复盘使用。',
    psychology: '分析对手意图、压迫和资源保留信号。',
    comboChain: '识别并评估连招路线。',
    narrator: '将决策信号转换为可读说明。',
};
const METHOD_NAMES = { reset: '重置统计', start: '开始计时', end: '结束计时', profile: '记录耗时', stats: '查询统计', enable: '开关控制', open: '打开面板',
    remember: '记录记忆', attack: '记录进攻', aid: '记录援助', recall: '查询玩家记忆', hostility: '查询敌意', bonus: '查询评分加成', list: '查看列表',
    deterrence: '分析威慑', intent: '分析意图', pressure: '分析压力', hold: '分析保留策略', detect: '识别连招', score: '计算评分', priority: '查询优先级',
    narrate: '生成说明', render: '显示说明', recent: '查询最近说明', show: '打开说明面板' };

function _checkOne(key, contract, D) {
    const cur = D[key];
    if (typeof cur !== 'object' || cur === null) return { bad: true, reason: '模块接口未正确挂载（当前类型：' + typeof cur + '）' };
    for (const m of contract.methods) {
        if (typeof cur[m] !== 'function') return { bad: true, reason: '缺少“' + (METHOD_NAMES[m] || m) + '”接口（' + m + '）' };
    }
    return { bad: false };
}

/* ================= 主入口：开机自修复 ================= */
export async function selfHeal() {
    try {
        const D = window.__DJSC;
        if (!D) return { ok: false, err: 'window.__DJSC 不存在' };

        const healed = [];
        const failed = [];
        const explanations = [];

        for (const key in CONTRACTS) {
            const contract = CONTRACTS[key];
            const check = _checkOne(key, contract, D);
            if (!check.bad) continue;

            try {
                const mod = await import(contract.file);
                D[key] = contract.rebuild(mod);
                const verified = _checkOne(key, contract, D);
                if (verified.bad) throw new Error(verified.reason);
                healed.push(key + '（原因：' + check.reason + '）');
                explanations.push('已恢复：' + (MODULE_NAMES[key] || key) + '（' + key + '）',
                    '发现问题：' + check.reason, '用途：' + (MODULE_USES[key] || '恢复该模块的标准接口。'));
            } catch (e) {
                failed.push((MODULE_NAMES[key] || key) + '（' + key + '）：' + e.message);
            }
        }

        if (healed.length) {
            try { log.info('selfHeal', ['[无名AI · 飞雀模型V2][自修复] 接口检查完成'].concat(explanations)); } catch (e) { if (typeof window !== 'undefined' && window.__DJSC && window.__DJSC.swallow) window.__DJSC.swallow(e); }
        }
        if (failed.length) {
            try { log.warn('selfHeal', '失败：' + failed.join('、')); } catch (e) { if (typeof window !== 'undefined' && window.__DJSC && window.__DJSC.swallow) window.__DJSC.swallow(e); }
        }

        return { ok: true, healed: healed, failed: failed };
    } catch (e) {
        return { ok: false, err: e.message };
    }
}

export function autoSelfHeal(delay) {
    setTimeout(function () { selfHeal(); }, delay || 3000);
}

/* ================= 挂载 ================= */
if (typeof window !== 'undefined') {
    window.__DJSC = window.__DJSC || {};
    window.__DJSC.selfHeal = {
        run: selfHeal,
        auto: autoSelfHeal,
    };
}
